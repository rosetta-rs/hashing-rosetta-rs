#!/bin/bash

COUNTER=1
for D in **/*_2/report; do
  cp "${D}/pdf.svg" "./dir_${counter}.svg"
  COUNTER=$[COUNTER +1]
done
